const audioInput = document.getElementById('audio');
const imageInput = document.getElementById('image');
const previewVideo = document.getElementById('preview-video');
const mergeButton = document.getElementById('merge-button');
const downloadButton = document.getElementById('download-button');
const progressBar = document.querySelector('.progress-bar .progress');

function handleFileChange(input) {
    const file = input.files[0];

    // تأكد من وجود ملف
    if (!file) {
        return;
    }

    // اقرأ الملف
    const reader = new FileReader();
    reader.onload = function() {
        if (input === audioInput) {
            previewVideo.src = reader.result;
        } else if (input === imageInput) {
            // ...
        }
    };
    reader.readAsDataURL(file);
}

async function merge() {
    // ...
}

function download() {
    // ...
}
